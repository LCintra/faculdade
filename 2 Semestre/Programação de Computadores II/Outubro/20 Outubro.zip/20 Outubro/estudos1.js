var soma5 = function(x,y){
    return x+y
}
console.log(`A soma de 2 numeros é ${soma5(3,8)}`)

//E6
var soma6 = (x,y) => x+y
console.log(`A soma de 2 numeros é ${soma6(3,8)}`) 

    var codigo = Number(prompt(`Informe codigo`))
    console.log(vet.filter((objeto) => (objeto.codigo == codigo)))




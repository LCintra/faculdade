var vetor = [10,20,30,40,50]
var soma = 0
vetor.forEach(
        (elemento) => soma = soma+elemento
    )
console.log(`A soma dos elementos é ${soma}`)
/*function fsoma(elemento){
    soma = soma+elemento
}*/

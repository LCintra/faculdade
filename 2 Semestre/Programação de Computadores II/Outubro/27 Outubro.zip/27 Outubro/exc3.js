class rio{
    constructor(nome,nivel,poluido){
        this.nome = nome
        this.nivel = nivel
        this.poluido = poluido
    }

}
rio1 = new rio(`São Francisco`,3,false)
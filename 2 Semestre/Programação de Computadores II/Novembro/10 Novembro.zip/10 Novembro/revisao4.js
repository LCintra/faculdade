let vetor = [1,3,4,9]
let impares = vetor.find((elemento) =>{
    return elemento %2 == 1
})
console.log(impares)
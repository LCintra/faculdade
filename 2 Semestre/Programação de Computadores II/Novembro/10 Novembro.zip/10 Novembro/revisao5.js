let vetor = [1,4,2,6,9]
let soma = vetor.reduce((elemento)=>{
    return elemento + total
})
console.log(soma)
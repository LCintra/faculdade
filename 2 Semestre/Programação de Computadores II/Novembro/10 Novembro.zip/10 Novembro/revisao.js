vetor = [1,2,4]
let novo = vetor.map((elemento) => {
    return elemento+10
})
console.log(novo)

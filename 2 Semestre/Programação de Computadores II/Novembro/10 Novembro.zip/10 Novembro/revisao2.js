let vetor = [1,2,4]
vetor.forEach((elemento) => {
    if(elemento%2==0){
        console.log(`Elemento ${elemento} é par`)
    }
})
